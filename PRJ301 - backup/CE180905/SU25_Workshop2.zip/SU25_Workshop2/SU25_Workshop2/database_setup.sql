-- SQL script to create tables and test data

-- Create major table
CREATE TABLE major (
    major_id INT IDENTITY(1,1) PRIMARY KEY,
    major_name NVARCHAR(100) NOT NULL
);

-- Create student table
CREATE TABLE student (
    roll_Id NVARCHAR(50) PRIMARY KEY,
    first_name NVARCHAR(100) NOT NULL,
    last_name NVARCHAR(100) NOT NULL,
    gender INT NOT NULL, -- 1: Male, 0: Female
    password NVARCHAR(255) NOT NULL, -- MD5 hashed
    math FLOAT NOT NULL,
    english FLOAT NOT NULL,
    major_id INT,
    FOREIGN KEY (major_id) REFERENCES major(major_id)
);

-- Insert major data
INSERT INTO major (major_name) VALUES 
('Computer Engineering'),
('Information Technology'),
('Software Engineering'),
('Business Administration');

-- Insert test students
-- Password '123456' hashed with MD5 = 'e10adc3949ba59abbe56e057f20f883e'
INSERT INTO student (roll_Id, first_name, last_name, gender, password, math, english, major_id) VALUES 
('CE123456', 'John', 'Doe', 1, 'e10adc3949ba59abbe56e057f20f883e', 3.0, 4.5, 3),
('IT123457', 'Jane', 'Smith', 0, 'e10adc3949ba59abbe56e057f20f883e', 4.2, 8.2, 2),
('SE123458', 'Bob', 'Johnson', 1, 'e10adc3949ba59abbe56e057f20f883e', 7.9, 4.5, 3),
('BA123459', 'Alice', 'Wilson', 0, 'e10adc3949ba59abbe56e057f20f883e', 8.5, 7.8, 1);

-- GPA calculations:
-- CE123456: GPA = (2 × 3.0) + 4.5 / 3 = 10.5 / 3 = 3.50 (RED - less than 5)
-- IT123457: GPA = (2 × 4.2) + 8.2 / 3 = 16.6 / 3 = 5.53 (normal)
-- SE123458: GPA = (2 × 7.9) + 4.5 / 3 = 20.3 / 3 = 6.77 (normal) 
-- BA123459: GPA = (2 × 8.5) + 7.8 / 3 = 25.8 / 3 = 8.60 (excellent)
