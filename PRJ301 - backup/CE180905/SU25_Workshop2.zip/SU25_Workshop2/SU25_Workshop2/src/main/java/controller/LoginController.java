package controller;

import dao.StudentDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Student;

import java.io.IOException;

@WebServlet(urlPatterns = "/login")
public class LoginController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Check if user is already logged in
        HttpSession session = req.getSession(false);
        if (session != null && session.getAttribute("student") != null) {
            // User already logged in, redirect to profile
            resp.sendRedirect(req.getContextPath() + "/profile");
            return;
        }
        
        // Check if logout success message should be displayed
        String logoutParam = req.getParameter("logout");
        if ("success".equals(logoutParam)) {
            req.setAttribute("successMessage", "You have successfully logged out!");
        }
        
        // User not logged in, show login page
        req.getRequestDispatcher("/WEB-INF/view/auth/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Get parameters from login form
        String rollId = req.getParameter("roll");
        String password = req.getParameter("password");
        
        // Validate input parameters
        if (rollId == null || rollId.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            req.setAttribute("error", "Roll ID and password are required");
            req.getRequestDispatcher("/WEB-INF/view/auth/login.jsp").forward(req, resp);
            return;
        }
        
        // Authenticate user
        StudentDAO dao = new StudentDAO();
        Student student = dao.login(rollId, password);
        
        if (student != null) {
            // Login successful - create session and store user info
            HttpSession session = req.getSession();
            session.setAttribute("student", student);
            session.setAttribute("rollId", student.getRollId());
            session.setAttribute("fullName", student.getFirstName() + " " + student.getLastName());
            
            // Redirect to profile page
            resp.sendRedirect(req.getContextPath() + "/profile");
        } else {
            // Login failed - set error message and forward back to login page
            req.setAttribute("error", "Invalid Roll ID or password");
            req.getRequestDispatcher("/WEB-INF/view/auth/login.jsp").forward(req, resp);
        }
    }
}
