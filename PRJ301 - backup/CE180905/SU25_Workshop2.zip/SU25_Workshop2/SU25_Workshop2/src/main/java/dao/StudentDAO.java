package dao;

import db.DBContext;
import model.Student;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StudentDAO extends DBContext {

    public Student login(String rollId, String password) {
        try {
            String hashedPassword = hashMd5(password);
            String query = "SELECT * FROM student WHERE roll_Id = ? AND password = ?";
            Object[] params = {rollId, hashedPassword};
            ResultSet rs = executeSelectQuery(query, params);
            if (rs.next()) {
                Student student = new Student();
                student.setRollId(rs.getString("roll_Id"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setGender(rs.getInt("gender"));
                student.setPassword(rs.getString("password"));
                student.setMath(rs.getDouble("math"));
                student.setEnglish(rs.getDouble("english"));
                student.setMajorId(rs.getInt("major_id"));
                return student;
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, "Error during login", ex);
        }
        return null;
    }

    public Student getStudentByRollId(String rollId) {
        try {
            String query = "SELECT * FROM student WHERE roll_Id = ?";
            Object[] params = {rollId};
            ResultSet rs = executeSelectQuery(query, params);

            if (rs.next()) {
                Student student = new Student();
                student.setRollId(rs.getString("roll_Id"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setGender(rs.getInt("gender"));
                student.setPassword(rs.getString("password"));
                student.setMath(rs.getDouble("math"));
                student.setEnglish(rs.getDouble("english"));
                student.setMajorId(rs.getInt("major_id"));
                return student;
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, "Error getting student by rollId", ex);
        }
        return null;
    }

    private String hashMd5(String raw) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] mess = md.digest(raw.getBytes());

            StringBuilder sb = new StringBuilder();
            for (byte b : mess) {
                sb.append(String.format("%02x", b));
            }

            return sb.toString();
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
            return "";
        }
    }

    public String getMajorNameById(int majorId) {
        try {
            String query = "SELECT name FROM major WHERE major_id = ?";
            Object[] params = {majorId};
            ResultSet rs = executeSelectQuery(query, params);

            if (rs.next()) {
                return rs.getString("name");
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, "Error getting major name", ex);
        }
        return "Unknown Major";
    }
}
