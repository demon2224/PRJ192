package controller;

import dao.StudentDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Student;

import java.io.IOException;

@WebServlet(name = "StudentController", urlPatterns = {"/profile"})
public class StudentController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("student") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }
        Student student = (Student) session.getAttribute("student");
        
        // Get major name for the student
        StudentDAO studentDAO = new StudentDAO();
        String majorName = studentDAO.getMajorNameById(student.getMajorId());
        
        req.setAttribute("student", student);
        req.setAttribute("majorName", majorName);
        req.getRequestDispatcher("/WEB-INF/view/profile/profile.jsp").forward(req, resp);
    }
}
