package model;

public class Student {

    private String rollId;
    private String firstName;
    private String lastName;
    private int gender;
    private String password;
    private double math;
    private double english;
    private int majorId;

    public Student() {
    }

    public Student(String rollId, String firstName, String lastName, int gender, String password, double math, double english, int majorId) {
        this.rollId = rollId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.password = password;
        this.math = math;
        this.english = english;
        this.majorId = majorId;
    }

    public String getRollId() {
        return rollId;
    }

    public void setRollId(String rollId) {
        this.rollId = rollId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getMath() {
        return math;
    }

    public void setMath(double math) {
        this.math = math;
    }

    public double getEnglish() {
        return english;
    }

    public void setEnglish(double english) {
        this.english = english;
    }

    public int getMajorId() {
        return majorId;
    }

    public void setMajorId(int majorId) {
        this.majorId = majorId;
    }

    // Utility methods
    public String getFullName() {
        return firstName + " " + lastName;
    }

    public String getGenderString() {
        return gender == 1 ? "Male" : "Female";
    }

    // Alternative method following the exact convention from requirements
    public String getGenderDisplay() {
        if (gender == 0) {
            return "Female for gender value = 0";
        } else if (gender == 1) {
            return "Male for gender value = 1";
        } else {
            return "Unknown";
        }
    }

    public double getAverageScore() {
        return (math + english) / 2.0;
    }

    // GPA calculation using the formula: GPA = (2 × math) + english / 3
    public double getGpa() {
        return ((2 * math) + english) / 3.0;
    }

    // Method to format GPA to 2 decimal places
    public String getFormattedGpa() {
        return String.format("%.2f", getGpa());
    }

    @Override
    public String toString() {
        return "Student{"
                + "rollId='" + rollId + '\''
                + ", firstName='" + firstName + '\''
                + ", lastName='" + lastName + '\''
                + ", gender=" + gender
                + ", math=" + math
                + ", english=" + english
                + ", majorId=" + majorId
                + '}';
    }
}
